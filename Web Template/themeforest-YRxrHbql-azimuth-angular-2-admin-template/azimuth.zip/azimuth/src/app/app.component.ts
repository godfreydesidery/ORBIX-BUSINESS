import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'az-root',
  standalone: true,
  imports: [RouterOutlet],
  template:`<router-outlet />`
})
export class AppComponent { }
